package com.joe.concerthub.data.model

import com.joe.concerthub.R

data class Concert(
    val id: String,
    val title: String,
    val artist: String,
    val venue: String,
    val city: String,
    val date: String,
    val price: Int,
    val imageEmoji: String,
    val imageRes: Int,
    val category: String,
    val availableSeats: Int
)

val dummyConcerts = listOf(
    Concert(
        id = "1",
        title = "Konser Dewa 19",
        artist = "Dewa 19",
        venue = "GBK Arena",
        city = "Jakarta",
        date = "15 Jul 2025",
        price = 350000,
        imageEmoji = "🎸",
        imageRes = R.drawable.poster_dewa19,
        category = "Rock",
        availableSeats = 500
    ),
    Concert(
        id = "2",
        title = "Coldplay World Tour",
        artist = "Coldplay",
        venue = "GBK Stadion",
        city = "Jakarta",
        date = "1 Agu 2025",
        price = 1500000,
        imageEmoji = "🌟",
        imageRes = R.drawable.poster_coldplay,
        category = "Pop",
        availableSeats = 50000
    ),
    Concert(
        id = "3",
        title = "Sheila On 7 Reunion",
        artist = "Sheila On 7",
        venue = "Jogja Expo Center",
        city = "Yogyakarta",
        date = "5 Sep 2025",
        price = 300000,
        imageEmoji = "🎵",
        imageRes = R.drawable.poster_so7,
        category = "Pop",
        availableSeats = 800
    ),
    Concert(
        id = "4",
        title = "Avenged Sevenfold Live",
        artist = "Avenged Sevenfold",
        venue = "Beach City International Stadium",
        city = "Ancol, Jakarta",
        date = "20 Sep 2025",
        price = 750000,
        imageEmoji = "🤘",
        imageRes = R.drawable.poster_a7x,
        category = "Metal",
        availableSeats = 15000
    ),
    Concert(
        id = "5",
        title = "My Chemical Romance Tour",
        artist = "My Chemical Romance",
        venue = "Indonesia Arena",
        city = "Jakarta",
        date = "10 Okt 2025",
        price = 850000,
        imageEmoji = "🖤",
        imageRes = R.drawable.poster_mcr,
        category = "Rock",
        availableSeats = 12000
    ),
)