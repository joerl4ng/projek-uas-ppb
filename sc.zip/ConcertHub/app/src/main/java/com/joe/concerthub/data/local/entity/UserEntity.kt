package com.joe.concerthub.data.local.entity

data class UserEntity(
    val id: String,
    val name: String,
    val email: String,
    val passwordHash: String,
    val createdAt: String
)