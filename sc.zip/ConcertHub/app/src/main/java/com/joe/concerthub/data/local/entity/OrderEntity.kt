package com.joe.concerthub.data.local.entity

data class OrderEntity(
    val id: String,
    val concertId: String,
    val concertTitle: String,
    val artist: String,
    val date: String,
    val quantity: Int,
    val totalPrice: Int,
    val buyerName: String,
    val buyerEmail: String,
    val buyerPhone: String,
    val status: String,
    val createdAt: String
)