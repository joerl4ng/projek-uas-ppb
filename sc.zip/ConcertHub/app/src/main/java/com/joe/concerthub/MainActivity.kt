package com.joe.concerthub

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.navigation.compose.rememberNavController
import com.joe.concerthub.navigation.NavGraph
import com.joe.concerthub.ui.theme.ConcertHubTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ConcertHubTheme {
                val navController = rememberNavController()
                NavGraph(navController = navController)
            }
        }
    }
}