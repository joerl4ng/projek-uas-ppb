package com.joe.concerthub.data.local

import android.content.ContentValues
import android.content.Context
import com.joe.concerthub.data.local.entity.OrderEntity
import com.joe.concerthub.data.local.entity.UserEntity
import net.sqlcipher.Cursor
import net.sqlcipher.database.SQLiteDatabase
import net.sqlcipher.database.SQLiteOpenHelper

class DatabaseHelper(private val context: Context) : SQLiteOpenHelper(
    context, DATABASE_NAME, null, DATABASE_VERSION
) {
    companion object {
        private const val DATABASE_NAME = "concerthub.db"
        private const val DATABASE_VERSION = 2
        private const val TABLE_ORDERS = "orders"
        private const val TABLE_USERS = "users"
        const val DB_PASSPHRASE = "C0nc3rtHub@S3cur3K3y!"
    }

    init {
        SQLiteDatabase.loadLibs(context)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS $TABLE_USERS (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """.trimIndent())

        db.execSQL("""
            CREATE TABLE IF NOT EXISTS $TABLE_ORDERS (
                id TEXT PRIMARY KEY,
                concert_id TEXT NOT NULL,
                concert_title TEXT NOT NULL,
                artist TEXT NOT NULL,
                date TEXT NOT NULL,
                quantity INTEGER NOT NULL,
                total_price INTEGER NOT NULL,
                buyer_name TEXT NOT NULL,
                buyer_email TEXT NOT NULL,
                buyer_phone TEXT NOT NULL,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """.trimIndent())
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_ORDERS")
        onCreate(db)
    }

    // ===== USER =====

    fun registerUser(user: UserEntity): Boolean {
        val db = this.getWritableDatabase(DB_PASSPHRASE)
        return try {
            val values = ContentValues().apply {
                put("id", user.id)
                put("name", user.name)
                put("email", user.email)
                put("password_hash", user.passwordHash)
                put("created_at", user.createdAt)
            }
            db.insert(TABLE_USERS, null, values) != -1L
        } catch (e: Exception) {
            false
        } finally {
            db.close()
        }
    }

    fun loginUser(email: String, passwordHash: String): UserEntity? {
        val db = this.getReadableDatabase(DB_PASSPHRASE)
        var cursor: Cursor? = null
        return try {
            cursor = db.rawQuery(
                "SELECT * FROM $TABLE_USERS WHERE email = ? AND password_hash = ?",
                arrayOf(email, passwordHash)
            )
            if (cursor != null && cursor.moveToFirst()) {
                UserEntity(
                    id = cursor.getString(cursor.getColumnIndexOrThrow("id")),
                    name = cursor.getString(cursor.getColumnIndexOrThrow("name")),
                    email = cursor.getString(cursor.getColumnIndexOrThrow("email")),
                    passwordHash = cursor.getString(cursor.getColumnIndexOrThrow("password_hash")),
                    createdAt = cursor.getString(cursor.getColumnIndexOrThrow("created_at"))
                )
            } else null
        } catch (e: Exception) {
            null
        } finally {
            cursor?.close()
            db.close()
        }
    }

    fun isEmailRegistered(email: String): Boolean {
        val db = this.getReadableDatabase(DB_PASSPHRASE)
        var cursor: Cursor? = null
        return try {
            cursor = db.rawQuery(
                "SELECT id FROM $TABLE_USERS WHERE email = ?",
                arrayOf(email)
            )
            cursor != null && cursor.moveToFirst()
        } catch (e: Exception) {
            false
        } finally {
            cursor?.close()
            db.close()
        }
    }

    // ===== ORDER =====

    fun insertOrder(order: OrderEntity): Boolean {
        val db = this.getWritableDatabase(DB_PASSPHRASE)
        return try {
            val values = ContentValues().apply {
                put("id", order.id)
                put("concert_id", order.concertId)
                put("concert_title", order.concertTitle)
                put("artist", order.artist)
                put("date", order.date)
                put("quantity", order.quantity)
                put("total_price", order.totalPrice)
                put("buyer_name", order.buyerName)
                put("buyer_email", order.buyerEmail)
                put("buyer_phone", order.buyerPhone)
                put("status", order.status)
                put("created_at", order.createdAt)
            }
            db.insert(TABLE_ORDERS, null, values) != -1L
        } catch (e: Exception) {
            false
        } finally {
            db.close()
        }
    }

    fun getAllOrders(): List<OrderEntity> {
        val db = this.getReadableDatabase(DB_PASSPHRASE)
        val orders = mutableListOf<OrderEntity>()
        var cursor: Cursor? = null
        return try {
            cursor = db.rawQuery("SELECT * FROM $TABLE_ORDERS ORDER BY created_at DESC", null)
            if (cursor != null) {
                while (cursor.moveToNext()) {
                    orders.add(
                        OrderEntity(
                            id = cursor.getString(cursor.getColumnIndexOrThrow("id")),
                            concertId = cursor.getString(cursor.getColumnIndexOrThrow("concert_id")),
                            concertTitle = cursor.getString(cursor.getColumnIndexOrThrow("concert_title")),
                            artist = cursor.getString(cursor.getColumnIndexOrThrow("artist")),
                            date = cursor.getString(cursor.getColumnIndexOrThrow("date")),
                            quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity")),
                            totalPrice = cursor.getInt(cursor.getColumnIndexOrThrow("total_price")),
                            buyerName = cursor.getString(cursor.getColumnIndexOrThrow("buyer_name")),
                            buyerEmail = cursor.getString(cursor.getColumnIndexOrThrow("buyer_email")),
                            buyerPhone = cursor.getString(cursor.getColumnIndexOrThrow("buyer_phone")),
                            status = cursor.getString(cursor.getColumnIndexOrThrow("status")),
                            createdAt = cursor.getString(cursor.getColumnIndexOrThrow("created_at"))
                        )
                    )
                }
            }
            orders
        } catch (e: Exception) {
            emptyList()
        } finally {
            cursor?.close()
            db.close()
        }
    }
}