package com.joe.concerthub.navigation

import android.R.attr.type
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.joe.concerthub.ui.screens.auth.LoginScreen
import com.joe.concerthub.ui.screens.auth.RegisterScreen
import com.joe.concerthub.ui.screens.detail.DetailScreen
import com.joe.concerthub.ui.screens.home.HomeScreen
import com.joe.concerthub.ui.screens.order.OrderHistoryScreen
import com.joe.concerthub.ui.screens.order.OrderScreen
import com.joe.concerthub.ui.screens.profile.ProfileScreen
import com.joe.concerthub.ui.screens.splash.SplashScreen

@Composable
fun NavGraph(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = Screen.Splash.route
    ) {
        composable(Screen.Splash.route) {
            SplashScreen(navController = navController)
        }
        composable(Screen.Login.route) {
            LoginScreen(navController = navController)
        }
        composable(Screen.Register.route) {
            RegisterScreen(navController = navController)
        }
        composable(Screen.Home.route) {
            HomeScreen(navController = navController)
        }
        composable(
            route = Screen.Detail.route,
            arguments = listOf(navArgument("concertId") { type = NavType.StringType })
        ) { backStackEntry ->
            DetailScreen(
                navController = navController,
                concertId = backStackEntry.arguments?.getString("concertId") ?: ""
            )
        }
        composable(
            route = Screen.Order.route,
            arguments = listOf(navArgument("concertId") { type = NavType.StringType })
        ) { backStackEntry ->
            OrderScreen(
                navController = navController,
                concertId = backStackEntry.arguments?.getString("concertId") ?: ""
            )
        }
        composable(Screen.OrderHistory.route) {
            OrderHistoryScreen(navController = navController)
        }
        composable(Screen.Profile.route) {
            ProfileScreen(navController = navController)
        }
    }
}