package com.joe.concerthub.security

object InputValidator {

    fun isValidEmail(email: String): Boolean {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    fun isValidPassword(password: String): Boolean {
        // Minimal 8 karakter, huruf besar, huruf kecil, angka
        val passwordRegex = Regex("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).{8,}$")
        return passwordRegex.matches(password)
    }

    fun isValidPhone(phone: String): Boolean {
        val phoneRegex = Regex("^(\\+62|62|0)8[1-9][0-9]{6,9}$")
        return phoneRegex.matches(phone)
    }

    fun sanitizeInput(input: String): String {
        // Hapus karakter berbahaya untuk mencegah injection
        return input
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&#x27;")
            .replace("/", "&#x2F;")
            .trim()
    }

    fun isValidName(name: String): Boolean {
        return name.isNotBlank() && name.length >= 3 && name.length <= 100
    }
}