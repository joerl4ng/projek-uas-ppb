package com.joe.concerthub.ui.theme

import androidx.compose.ui.graphics.Color

// Primary - Orange ConcertHub
val OrangePrimary = Color(0xFFFF6B00)
val OrangeLight = Color(0xFFFF8C3A)
val OrangeDark = Color(0xFFCC5500)

// Background - Dark
val BackgroundDark = Color(0xFF0D0D0D)
val SurfaceDark = Color(0xFF1A1A1A)
val CardDark = Color(0xFF242424)

// Text
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFB0B0B0)
val TextHint = Color(0xFF6B6B6B)

// Status
val SuccessGreen = Color(0xFF4CAF50)
val ErrorRed = Color(0xFFE53935)
val WarningYellow = Color(0xFFFFC107)

// Misc
val DividerColor = Color(0xFF2A2A2A)