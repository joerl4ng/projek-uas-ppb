package com.joe.concerthub.navigation

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Login : Screen("login")
    object Register : Screen("register")
    object Home : Screen("home")
    object Detail : Screen("detail/{concertId}") {
        fun createRoute(concertId: String) = "detail/$concertId"
    }
    object Order : Screen("order/{concertId}") {
        fun createRoute(concertId: String) = "order/$concertId"
    }
    object OrderHistory : Screen("order_history")
    object Profile : Screen("profile")
}