package com.joe.concerthub.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.joe.concerthub.ui.theme.OrangePrimary
import com.joe.concerthub.ui.theme.TextPrimary

@Composable
fun ConcertHubLogo(fontSize: TextUnit = 28.sp) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = "Concert",
            fontSize = fontSize,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )
        Box(
            modifier = Modifier
                .padding(start = 6.dp)
                .background(OrangePrimary, RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp, vertical = 2.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "hub",
                fontSize = fontSize,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }
    }
}